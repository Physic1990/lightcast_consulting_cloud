
# Origins is your allowed url list for your FastAPI Cors middleware. This needs to include your backend urls and your frontend urls
origins = ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173", "http://127.0.0.1:5173"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # You can specify the allowed HTTP methods here
    allow_headers=["*"],  # You can specify the allowed headers here
)

def get_google_auth(request: Request):
    '''
    get_google_auth function handles getting the google auth client JSON file from the absolute file path. The JSON file is what the 
    Google API console gives you after setting up the authentication stuff. Allowed urls need to include both your localhost and production urls. 
    We need to verify the the urls this prevents some security concerns of cross-site scriping vulnerabilities. The flow takes in the JSON secrets file
    and the Google API scopes (this is what the user is allowed to do through google) and the redirect_uri handles the Google redirecting between your backend
    application and Googles handling of authentication.
    '''
    # Google provided client id from the console or within the JSON FILE
    google_client_id = ""
    client_secret_file = os.path.join(pathlib.Path(__file__).parent, ".json")
    
    allowed_base_urls = ['http://localhost:3000']

    base_url = str(request.base_url).rstrip('/')
    if base_url in allowed_base_urls:
        redirect_uri = f"{base_url}/callback"
    else:
        raise HTTPException(status_code=400, detail="Invalid authorization base URL")

    flow = Flow.from_client_secrets_file(
        client_secrets_file=client_secret_file,
        scopes=["https://www.googleapis.com/auth/userinfo.profile", 
            "https://www.googleapis.com/auth/userinfo.email", "openid"],
        redirect_uri=redirect_uri
    )

    return flow, google_client_id

# Google login route
@app.get('/login')
async def login(request: Request):
    '''
    Login route handles the pass off from FastAPI to Google Oauth.
    '''
    flow, _ = get_google_auth(request)
    authorization_url, state = flow.authorization_url(prompt='consent', access_type='offline')
    request.session["state"] = state # We grab the session state variable here

    return RedirectResponse(authorization_url)

# Google OAuth callback route
@app.get('/callback')
async def callback(request: Request):
    '''
    Callback route handles the pass off from Google Oauth back to the FastAPI backend. We check the state and ensure everything
    in the session is correct. After comfirming the state and grab the access token from Google Oauth we need to verify the access token between
    the backend and the frontend by generating an encrypted jwt token. The jwt token has an expiration of 1 hour. 
    '''
    try:
        try:
            flow, google_client_id = get_google_auth(request)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Auth setup error: {str(e)}")

        try:
            flow.fetch_token(authorization_response=str(request.url))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Token fetch error: {str(e)}")
        
        if "state" not in request.session:
            raise HTTPException(status_code=400, detail="No state in session")
        
        if request.session["state"] != request.query_params.get("state"):
            raise HTTPException(status_code=403, detail="State mismatch")
        
        # Get credentials and verify token
        credentials = flow.credentials
        
        try:
            token_request = requests.Request()
            # Google function for verifying oauth token
            id_info = id_token.verify_oauth2_token(credentials._id_token, token_request, google_client_id)
        except Exception as e:
            raise HTTPException(status_code=403, detail=f"Invalid token: {str(e)}")

        jwt_token = jwt.encode(
            {"sub": id_info["email"], "name": id_info["name"],
            "exp": datetime.utcnow() + timedelta(hours=1)},
            SECRET_KEY, 
            algorithm='HS256'
        )
        
        # This will need to reflect your production url for your frontend.
        redirect_url = "http://localhost:5173"
        response = RedirectResponse(url=redirect_url, status_code=HTTP_302_FOUND)
        
        # Set the cookie
        # The cookies is what the frontend uses to verify that you are a valid user
        response.set_cookie(
            key="access_token", 
            value=jwt_token, 
            httponly=True, 
            samesite="Lax",
            secure=False  # Set to True in production with HTTPS
        )

        return response
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Authentication error: {str(e)}")

@app.get("/validate-token")
async def validate_token(request: Request):
    '''
    Lightweight function for your frontend code to use for verifying that the user is still authorized to move around your application.
    This just grabs the cookie from the webbrowser and validates.


    Notes: This should be utilized for clicking around in your frontend. Once you make the request to this route it will either validate that the
    user is good to continue or if the access token is not valid you should redirect the user to the login page. React should handle the redirection of users
    back to the login page to authenticate back into your application.
    '''
    token = request.cookies.get("access_token")
    if not token:
        return JSONResponse(status_code=401, content={"error": "Not authenticated"})
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return JSONResponse(content={"valid": True, "user": {
            "email": payload.get("email"),
            "name": payload.get("name")
        }})
    except:
        return JSONResponse(status_code=401, content={"error": "Invalid token"})
    


'''
Here is the frontend code that hits the login route:

<button
    type="button"
    onClick={() =>
    (window.location.href = "http://localhost:3000/login")
    }
    className="flex items-center px-4 py-3 mb-5 text-sm font-medium text-gray-600 bg-white border-none rounded shadow-sm hover:shadow-md transition-all duration-300 bg-no-repeat"
    style={{
    backgroundImage:
        "url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMTcuNiA5LjJsLS4xLTEuOEg5djMuNGg0LjhDMTMuNiAxMiAxMyAxMyAxMiAxMy42djIuMmgzYTguOCA4LjggMCAwIDAgMi42LTYuNnoiIGZpbGw9IiM0Mjg1RjQiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik05IDE4YzIuNCAwIDQuNS0uOCA2LTIuMmwtMy0yLjJhNS40IDUuNCAwIDAgMS04LTIuOUgxVjEzYTkgOSAwIDAgMCA4IDV6IiBmaWxsPSIjMzRBODUzIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNNCAxMC43YTUuNCA1LjQgMCAwIDEgMC0zLjRWNUgxYTkgOSAwIDAgMCAwIDhsMy0yLjN6IiBmaWxsPSIjRkJCQzA1IiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNOSAzLjZjMS4zIDAgMi41LjQgMy40IDEuM0wxNSAyLjNBOSA5IDAgMCAwIDEgNWwzIDIuNGE1LjQgNS40IDAgMCAxIDUtMy43eiIgZmlsbD0iI0VBNDMzNSIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTAgMGgxOHYxOEgweiIvPjwvZz48L3N2Zz4=)",
    backgroundPosition: "12px 11px",
    paddingLeft: "42px",
    boxShadow:
        "0 -1px 0 rgba(0, 0, 0, .04), 0 1px 1px rgba(0, 0, 0, .25)",
    }}
>
    Sign in with Google
</button>

'''
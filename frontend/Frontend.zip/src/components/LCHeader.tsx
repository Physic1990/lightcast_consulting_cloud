export default function LCHeader() {
  return (
    <div>
      <div style={{ width: "100%", marginRight: "auto" }}>
        <img src="/src/assets/LCLogo.png" width={250} />
      </div>
    </div>
  );
}
